package com.example.edutech.pago.model;

public enum TipoDescuento {
    PORCENTAJE, 
    MONTO_FIJO   
}