package com.example.edutech.soporte.model;

public enum PrioridadTicketSoporte {
    BAJA,
    MEDIA,
    ALTA,
    URGENTE
}